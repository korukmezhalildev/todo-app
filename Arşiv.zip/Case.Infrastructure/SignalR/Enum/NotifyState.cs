namespace Case.Infrastructure.SignalR.Enum;

public enum NotifyState
{
    Created,
    Updated,
    Deleted
}