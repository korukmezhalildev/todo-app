namespace Case.Application.Dtos;

public record LoginDto(string email, string password);