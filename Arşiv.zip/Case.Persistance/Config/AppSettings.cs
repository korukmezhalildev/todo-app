namespace Case.Persistance.Config;

public class AppSettings
{
    public required string Secret { get; set; }
}